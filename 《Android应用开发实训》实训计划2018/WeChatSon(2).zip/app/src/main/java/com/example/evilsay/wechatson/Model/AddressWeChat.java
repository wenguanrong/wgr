package com.example.evilsay.wechatson.Model;

public class AddressWeChat {
    private String name;
    private String user;
    public String getUser() {
        return user;
    }

    public void setUser(String user) {
        this.user = user;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

}
