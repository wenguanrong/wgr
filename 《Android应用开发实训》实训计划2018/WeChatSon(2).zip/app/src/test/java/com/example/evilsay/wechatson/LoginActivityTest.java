package com.example.evilsay.wechatson;

import org.junit.Test;

import static org.junit.Assert.*;

public class LoginActivityTest {

    @Test
    public void putDateForFragmentMe() {
    }
}